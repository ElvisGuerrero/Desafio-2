# -*- coding: utf-8 -*-
"""
Created on Tue Nov  9 22:27:14 2021

@author: Desktop
"""

def ciclo():
    
    print("\n\n\t ---MENU--- \n")
    print("Hola usuario, porfavor ingrese una opcion para elegir")
    print("Ingrese 1 para Generar el estado inicial del puerto seco")
    print("Ingrese 2 para Imprimir el estado del puerto seco ")
    print("Ingrese 3 para Ubicar un contenedor ")
    print("Ingrese 4 para Incluir un contenedor ")
    print("Ingrese 5 para Retirar un contenero")
    print("Ingrese 0 para cerrar su jornada laboral")
    


def impuertoS(puertoS,N,M):
	
	i = 0
	while (i < N-2):
		j = M - 1
		while (j > 0):
			if(puertoS[i][j]==0):
				return i,j
			j = j - 1
		i = i + 1
        
def retirarcontenedor(puertoS,N,M,a,b):
	
	print(N,M,a,b)
	
	if (b+1==N):
		print("Puedo retirar contenedor") # puerto[a][b] = 0
		return puertoS
	elif capacidadpuerto(puertoS,N,M)==0:
		print("No puedo retirar contenedor")
		return puertoS
	
	if(puertoS[a][b+1]==0):
		print("Puedo retirar contenedor") # puerto[a][b] = 0
		return puertoS
	else:
		print("Debo hacer los cambios para retirar contenedor")
		# sumar instrucciones para hacer los cambios
		# mirar desde la primera fila y primera columna buscando espacios vacios (0)..while
	return puertoS

def capacidadpuerto(puertoS,N,M):
	if N==M or N<M: 
		vacios = N 
	else:
		vacios = N + M - 1
	
	capacidad = (N+1)*(M) - vacios
	
	for pilas in puertoS:
		for cont in pilas:
			if cont != 0:
				capacidad = capacidad - 1
	
	return capacidad

def nuevocontenedor(puertoS,N,M):
	
	if capacidadpuerto(puertoS,N,M) == 0:
		print("El puerto está lleno. No podemos recibir su contenedor ")
	else:
		i = 0
		while(i<M):
			j = 0
			while(j<N):
				if puertoS[i][j] == 0: # Si es un espacio vacio
					puertoS[i][j] = input("Ingrese numero/NombreEmpresa: ")
					impuertoS(puertoS, N,M)
					return puertoS
				j = j + 1
			i = i + 1
	return puertoS

def puertoF(N,M):

	puertoS = [] 
	
	for i in range(M): # por cada pila pilas. M = 2. i = 0, i = 1
		cont = [] # creamos una lista para contenedores
		for j in range(N+1): # por cada espacio en la pila de contenedores. N = 2, j = 0, j = 1, j = 2
			cont.append(0) # incorporamos un 0, que denota un espacio libre
		puertoS.append(cont) #[[pila1],[pila2]]
	
	# definir cantidad de espacios disponibles
	if N==M or N<M: 
		vacios = N 
	else:
		vacios = N + M - 1
	
	# Estado inicial en un % que indique el usuario 
		
	inicio = int(input("Ingrese % de del estado inicial del puerto (1: lleno, 2: 50%, 3: vacío): "))
	disponible = (N+1)*(M) - vacios # la capacidad  maxima del puerto, dependiendo de N y M
	
	if inicio == 3: # Si el usuario indica que necesita el puerto vacio, entonces retornamos el puerto.
		return puertoS # Desde la linea 48 a la linea 52, se crea el puerto completo con espacios, por lo tanto esta vacio.
	elif inicio == 2:
		disponible = disponible / 2
	
	###################### Llenamos el puerto según condiciones
	
	
	i = 0
	while(i<M): # Por cada i que corresponde a un índice de una pila (M = pilas)
		j = 0
		while(j<N): # Por cada contenedor o elmento en la pila 
			if disponible > 0: # Si, nos queda capacidad real
				puertoS[i][j] = input("Ingrese numero/NombreEmpresa: ")
				disponible = disponible - 1
			j = j + 1
		i = i + 1
	return puertoS
	

def imprimepuerto(puertoS,N,M):

	i = N
	print("\n\n\n")
	while (i >= 0):
		j = M - 1
		print("| ", end = " ")
		while (j >= 0):
			print (puertoS[j][i], " | ", end=" ")
			j = j - 1
		print("")
		i = i - 1

def br(puertoS, cont):
	
	ON = -1
	i = 0
	while(i<len(puertoS)):
		
		if puertoS[i].count(cont) >= 0:
			ON= puertoS[i].index(cont)
			pilak = i
		i = i + 1
	if ON != -1:
		return (pilak,ON)
	else:
		return(-1,-1)
    
puertoS = []
ciclo()
fn = int(input("Ingrese una opcion: "))

while (fn != 0):
	
	if fn == 1:
		N = int(input("\n\n\nIngrese N: ")) # N+1
		M = int(input("Ingrese M: "))
		puertoS = puertoF(N,M)
	elif fn == 2:
		imprimepuerto(puertoS,N,M)
	elif fn == 3:
		cont = input("\n\n\nIngrese nombre del contenedor a buscar: \n")
		a,b = br(puertoS, cont)
		if (a == -1 and b == -1):
			imprimepuerto(puertoS,N,M)
			print("Contenedor no se encuentra en el puerto")
		else:
			imprimepuerto(puertoS, N,M)
			print("\nEl contenedor buscado ",cont,", se encuentra en la pila ", M-a," en el nivel ",b+1)
	elif fn == 4:
		puertoS = nuevocontenedor(puertoS,N,M)
	elif fn == 5:
		cont = input("\n\n\nIngrese nombre del contenedor a retirar: \n")
		a,b = br(puertoS, cont)
		if (a == -1 and b == -1):
			print("Contenedor no se encuentra en el puerto")
		else:
			imprimepuerto(puertoS, N,M)
			print("\nEl contenedor buscado ",cont,", se encuentra en la pila ", M-a," en el nivel ",b+1)
			puertoS =retirarcontenedor(puertoS,N,M,a,b)
	ciclo()
	fn = int(input("\nIngrese opción: "))	
		
print("\n\nFin jornada laboral")