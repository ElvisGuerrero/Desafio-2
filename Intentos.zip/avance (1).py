# -*- coding: utf-8 -*-
"""
Created on Mon Nov  1 15:10:25 2021

@author: elvis
"""
"Paso 1"
#Creacion del menu interactivo
def opciones():
    print("Hola usuario, porfavor ingrese una opcion para elegir")
    print("Ingrese 1 para Generar el estado inicial del puerto seco")
    print("Ingrese 2 para Imprimir el estado del puerto seco ")
    print("Ingrese 3 para Ubicar un contenedor ")
    print("Ingrese 4 para Incluir un contenedor ")
    print("Ingrese 5 para Retirar un contenero")
    print("Ingrese 0 para cerrar su jornada laboral")
    return

"Paso 2"
def opcion1(N,M):
    puertoS=[]
    
    if M>N or M==N:
        for i in range(M):
            cont=[]
            for o in range(N):
                cont.append(input("Ingrese Número/ NombreEmpresa: "))
            cont.append("V")
            puertoS.append(cont)

    else:
            for i in range(M):
                cont=[]
                for o in range(N):
                    if i == 0 and o == N-1:
                        cont.append(0)
                    else:
                        cont.append(input("Ingrese Número/NombreEmpresa: "))
                puertoS.append("V")
                puertoS.append(cont)
    return puertoS
    

def impresion(puerto,N,M):

	i = N-1
	while (i >= 0):
		o = M-1
		print("\ ", end = " ")
		while (o >= 0):
			print (puerto[o][i], " \ ", end=" ")
			o = o - 1
		print("")
		i = i - 1

def capacidadpuerto(puerto,N,M):
	if N==M or N<M: 
		vacios = N 
	else:
		vacios = N + M - 1
	
	capacidad = (N+1)*(M) - vacios
	
	for pilas in puerto:
		for contenedor in pilas:
			if contenedor != 0:
				capacidad = capacidad - 1
	
	return capacidad
    
def nuevocontenedor(puerto,N,M):
	
	if capacidadpuerto(puerto,N,M) == 0:
		print("El puerto está lleno. No podemos recibir su contenedor ")
	else:
		i = 0
		while(i<M):
			j = 0
			while(j<N):
				if puerto[i][j] == 0: # Si es un espacio vacio
					puerto[i][j] = input("Ingrese numero/NombreEmpresa: ")
					impresion(puerto, N,M)
					return puertoS
				j = j + 1
			i = i + 1
	return puerto			

def llenarpuerto(N,M):

	puerto = [] 
	
	for i in range(M): # por cada pila pilas. M = 2. i = 0, i = 1
		contenedores = [] # creamos una lista para contenedores
		for j in range(N+1): # por cada espacio en la pila de contenedores. N = 2, j = 0, j = 1, j = 2
			contenedores.append(0) # incorporamos un 0, que denota un espacio libre
		puerto.append(contenedores) #[[pila1],[pila2]]
	
	# definir cantidad de espacios disponibles
	if N==M or N<M: 
		vacios = N 
	else:
		vacios = N + M - 1
	
	# Estado inicial en un % que indique el usuario 
		
	inicio = int(input("Ingrese % de del estado inicial del puerto (1: lleno, 2: 50%, 3: vacío): "))
	disponible = (N+1)*(M) - vacios # la capacidad  maxima del puerto, dependiendo de N y M
	
	if inicio == 3: # Si el usuario indica que necesita el puerto vacio, entonces retornamos el puerto.
		return puerto # Desde la linea 48 a la linea 52, se crea el puerto completo con espacios, por lo tanto esta vacio.
	elif inicio == 2:
		disponible = disponible / 2
	
	###################### Llenamos el puerto según condiciones
	
	
	i = 0
	while(i<M): # Por cada i que corresponde a un índice de una pila (M = pilas)
		j = 0
		while(j<N): # Por cada contenedor o elmento en la pila 
			if disponible > 0: # Si, nos queda capacidad real
				puerto[i][j] = input("Ingrese numero/NombreEmpresa: ")
				disponible = disponible - 1
			j = j + 1
		i = i + 1
	return puerto

def buscar(puerto, contenedor):
	
	index = -1 # Variable auxiliar para identificar cuando encontrmos el elmento
	i = 0
	while(i<len(puerto)): # identificar el M
		
		if puerto[i].count(contenedor) > 0: # Cuantos elementos iguales a contenedor hay en la pila i
			index= puerto[i].index(contenedor)
			pilak = i
		i = i + 1
	if index != -1:
		return (pilak,index)
	else:
		return (-1,-1)

def retirar(puertoS,N,M,a,b):
    
    return puertoS

puertoS = []
opcion1()
op = int(input())

while (op != 6):
	
	if op == 1:
		N = int(input("\n\n\nIngrese N: ")) # N+1
		M = int(input("Ingrese M: "))
		puerto = llenarpuerto(N,M)
	elif op == 2:
		impresion(puerto,N,M)
	elif op == 3:
		contenedor = input("\n\n\nIngrese nombre del contenedor a buscar: \n")
		a,b = buscar(puerto, contenedor)
		if (a == -1 and b == -1):
			impresion(puerto, N,M)
			print("Contenedor no se encuentra en el puerto")
		else:
			impresion(puerto, N,M)
			print("\nEl contenedor buscado ",contenedor,", se encuentra en la pila ", M-a," en el nivel ",b+1)
	elif op == 4:
		puerto = nuevocontenedor(puerto,N,M)
	elif op == 5:
		contenedor = input("\n\n\nIngrese nombre del contenedor a retirar: \n")
		a,b = buscar(puerto, contenedor)
		if (a == -1 and b == -1):
			print("Contenedor no se encuentra en el puerto")
		else:
			impresion(puerto, N,M)
			print("\nEl contenedor buscado ",contenedor,", se encuentra en la pila ", M-a," en el nivel ",b+1)
			puertoS =retirar(puerto,N,M,a,b)
	opcion1()
	op = int(input("\nIngrese opción: "))	

puertoS = opcion1(N,M)
impresion(puertoS, N+1, M)
