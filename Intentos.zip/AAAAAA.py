# -*- coding: utf-8 -*-
"""
Created on Tue Nov  9 10:43:57 2021

@author: Desktop
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Nov  1 15:10:25 2021

@author: elvis
"""

def puertoF(N,M):

    puertoS=[]
    
    if M>N:
    
        for i in range(M):
            cont=[]
            for o in range(N):
                cont.append(input("Ingrese Número/ NombreEmpresa: "))
            cont.append(0)
            puertoS.append(cont)

    else:
            for i in range(M):
                cont=[]
                for o in range(N):
                    if i == 0 and o == N-1:
                        cont.append(0)
                    else:
                        cont.append(input("Ingrese Número/NombreEmpresa: "))
                puertoS.append(0)
                puertoS.append(cont)
    return puertoS
    

def impuertoS(puerto,N,M):

	i = N-1
	while (i >= 0):
		o = M-1
		print("\ ", end = " ")
		while (o >= 0):
			print (puerto[o][i], " \ ", end=" ")
			o = o - 1
		print("")
		i = i - 1

def br(puertoS, cont):
	
	ON = -1
	i = 0
	while(i<len(puertoS)):
		
		if puertoS[i].count(cont) >= 0:
			ON= puertoS[i].index(cont)
			pilak = i
		i = i + 1
	if ON != -1:
		return (pilak,ON)
	else:
		print("no se encuentra contenedor")
    

def incluir (N,M,cantidad):
    for v in range(cantidad):
        if N < cantidad:
            print("No es posible agregar mas contenedores a esta pila.")
        else:
            puerto.append(input("Ingrese que contenedor va a agregar."))
    return()

def ciclo():
    print("Hola usuario, porfavor ingrese una opcion para elegir")
    print("Ingrese 1 para Generar el estado inicial del puerto seco")
    print("Ingrese 2 para Imprimir el estado del puerto seco ")
    print("Ingrese 3 para Ubicar un contenedor ")
    print("Ingrese 4 para Incluir un contenedor ")
    print("Ingrese 5 para Retirar un contenero")
    print("Ingrese 0 para cerrar su jornada laboral")
    
N = int(input("Ingrese la maxima cantidad de contenedores en la pila: "))
M = int(input("Ingrese la cantidad de pilas de contenedores: "))

puerto = puertoF(N,M)

ciclo(N,M)
opcion = int(input(" Ingrese la opcion que desea: "))
    
Opcion=int(input("Ingrese el valor correspondiente: "))
while(Opcion>0):
    if Opcion==1 :
        cont=input("Ingrese el contenedor que desea buscar: ")
        a,b= br(puerto, cont)
        if a == 0 and b ==0:
            print("El contenedor no se encontro en el puerto")
        else:
            print("El contenedor", puerto[a][b], "fue encontrado el la pila ", a, "y en la pocision ", b)
    elif opcion == 2:
        cantidad = input("Ingrese la cantidad de contenedores que desea agregar: ")
        agregar = incluir (N,M,cantidad)
    elif opcion == 3:
        print("A")
    print()
    br(N,M)
    opcion = int(input("Ingrese su opcion: "))
           
    

if Opcion==0:
    print("Su jornada se cerro correctamente")
else:
    print(ciclo())


        
print(ciclo())

    